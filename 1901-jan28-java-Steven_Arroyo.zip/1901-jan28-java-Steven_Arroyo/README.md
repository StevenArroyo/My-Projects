# 1901-jan28-java

#WELCOME TO GITLAB, EVERYONE!

Here you'll find many helpful resources to complete this bootcamp.
Good luck!