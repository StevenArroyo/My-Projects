/* console.log("look at all this javascript!");
/* alert("panic!!!"); */
/*console.log("done with js script");
document.write('helloworld');
            
for(var i=0; i<14; i++){
    document.write("<br>");
    document.write('look at this dynamic js for loop: '+i);            
} */

console.log("we have javascript running in a seperate file!")


function MyFunc(){
var uriah = 5;
console.log(uriah);
}

MyFunc();