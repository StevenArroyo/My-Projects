Steven Arroyo's code
