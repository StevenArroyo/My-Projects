package Q3;

public class Q3 {

	
	public static void main (String[] args) {
		
		
		String s = "reverse me!"; // define the variable and give it a value of string
		for(int i = 0; i < s.length(); i++)
		{
		    s = s.substring(1, s.length() - i) + s.charAt(0) + s.substring(s.length() - i); // reverses the string and says it backwards
		}
		System.out.println(s); // print it out backwards in the console
	}
	
}
