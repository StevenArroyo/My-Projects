package Q11_2;

public class Q11_2 {
	
	public static float Float1 = 4.87f;
	public static float Float2 = 9.50f;

}
