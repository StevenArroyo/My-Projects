package Q12;

public class Q12 {

	public static void main (String[] args) {
		
		for(int i = 1; i<=100; i++) {
			if(i % 2 ==0) { //so if i is less than or equal to 100, print out ALL even numbers to 100
				System.out.println(i + " ");
			}
		}
	}
	
	
}
