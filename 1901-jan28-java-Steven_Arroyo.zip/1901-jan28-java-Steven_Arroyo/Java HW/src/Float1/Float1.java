package Float1;

public class Float1 {

}
