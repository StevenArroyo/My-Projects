package Q13;

public class Q13 {

	
	public static void main(String[] args) {

        String RightShapedTriangle = "";

        boolean goDownRight  = false;

        String counter = "0";

        for (int i = 0; i < 4; i++) {

            goDownRight = !goDownRight;

            if (i % 2 == 1) {

                if (counter == "0") {

                    counter = "1";

                } else {

                    counter = "0";

                }

            }

            if (goDownRight) {

                RightShapedTriangle = RightShapedTriangle + counter;

            } else {

                RightShapedTriangle = counter + RightShapedTriangle;

            }

            System.out.println(RightShapedTriangle);

        }

        

    }
	
}

