package Q5;

public class Q5 {

	public static void main (String[] args) {
		
		subString("Cookies", 2); //print out only the 2 letters of cookies, so it's "Co".
		
		
	}
	
	public static void subString(String str, int idx) {
		
		String name = "";
		for(int i = 0; i <= idx-1; i++) {
			
			name += str.charAt(i); //name the specific number of letters that i want to be shown
			
		}
		System.out.println(name); //print out the shtuff and shtuff
		
	}
	
	
	
	
	
}
