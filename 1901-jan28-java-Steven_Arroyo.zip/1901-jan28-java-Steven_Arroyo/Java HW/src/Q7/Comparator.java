package Q7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Comparator {

	public static void main(String[] args) {
		
		List<Q7> List = new ArrayList<Q7>(); // makes an arraylist named list
		
		
		List.add(new Q7("Ryan", "IT", 25)); //add this to the arraylist
		List.add(new Q7("Louis", "Design", 40)); //same here
		
		
		Collections.sort(List); // sort them out
		
		Collections.sort(List, new Q7()); 
			
		System.out.println(" ");
		
		for(Q7 a: List) {
			System.out.println(a.getName() +":  "+ a.getDep()+ " " + a.getAge() + " ");
		}
	}
	
}
