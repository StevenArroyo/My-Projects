package Q7;

import java.util.Comparator;


public class Q7 implements Comparator <Q7>, Comparable<Q7>{

	private String name; //name variable
	private String dep;// department variable
	private int age; // age variable
	
	
	Q7(){ // no args constructor
		
		
	}
	
	Q7(String name, String dep, int age){ // args constructor
		
		this.name = name; 
		this.dep = dep;
		this.age = age;
		
	}
	
	public String getName() { //method that returns the name
		return name;
	}
	
	public String getDep() { //returns the department name
		return dep;
	}
	
	public int getAge() { //returns the age number
		return age;
	}
	
	//these methods compare the names to everyone else's
	
	public int compareName(Q7 e) { 
		return(this.name).compareTo(e.name);
	}
	
	public int compareDep(Q7 e, Q7 e1) {
		return(this.dep).compareTo(e.dep);
	}
	
	public int compareAge(Q7 e, Q7 e1) {
		return e.age - e1.age;
	}

	@Override
	public int compareTo(Q7 o) {
	
		return 0;
	}

	@Override
	public int compare(Q7 o1, Q7 o2) {

		return 0;
	}
}


