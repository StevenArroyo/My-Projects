package Q16;

import java.util.Scanner;

public class Q16 {
	 public static void main(String[] args) {
	  
		 System.out.println(args[0].length());
		 
	 }
}
