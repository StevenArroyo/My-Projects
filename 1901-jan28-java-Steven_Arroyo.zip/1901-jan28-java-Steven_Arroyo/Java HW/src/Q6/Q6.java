package Q6;

public class Q6 {

	static boolean isEven(int n) 
	{ 
	      
	    // Return true if  
	    // n/2 does not result 
	    // in a float value. 
	    return ((n / 2) * 2 == n); 
	} 
	  
	
	public static void main(String[] args) 
	{ 
	    int n = 200; 
	    if(isEven(n) != false) { 
	        System.out.print( "Even" ); 
	    }else {
	    	System.out.print( "Odd" ); 
	    }
	} 
	 
		      

	
} 
	
       

