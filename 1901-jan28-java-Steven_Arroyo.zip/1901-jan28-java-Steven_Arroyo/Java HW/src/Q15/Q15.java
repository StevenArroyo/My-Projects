package Q15;


	
	class MathInterface {
		
		int number;// this will be the total of every method.
		
		public void adding(int a, int b) {
			
			number = a + b;
			System.out.println("Adding together equals: " + number);
			
		}
		
		public void subtracting(int a, int b) {
			number = a - b;
			System.out.println("Subtracting together equals: " + number);
		}
		
		public void multipliying(int a, int b) {
			number = a * b;
			System.out.println("Multiplying together equals: " + number);
		}
		
		public void dividing(int a, int b) {
			number = a / b;
			System.out.println("Dividing together equals: " + number);
		}
	}
	
	public class Q15 extends MathInterface{
	
		public static void main (String[] args) {
			
			int a = 5, b = 15; // default value for your int variables
			
			Q15 math = new Q15();// creates the math object for your class
			
			//this calls all 4 methods.
			math.adding(a, b);
			math.subtracting(a, b);
			math.dividing(a, b);
			math.multipliying(a, b);
		
		
	}
}
