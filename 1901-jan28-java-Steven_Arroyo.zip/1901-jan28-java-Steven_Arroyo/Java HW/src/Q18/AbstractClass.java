package Q18;

public abstract class AbstractClass {
	public abstract boolean hasUppercase(String str);

    public abstract String makeUppercase(String str);

    public abstract int convertToIntPlusTen(String str);
    
}
