package Q18;

public class TestAbstractClass {
	public static void main(String[] args){

		 

		        // Instantiate ConcreteClass object and input strings

		        ConcreteClass test = new ConcreteClass();

		        String str = "What can change the nature of a man?";

		        String num = "372";

		        

		        // Display original string and results of ConcreteClass methods

		        System.out.println("Original: " + str);

		        System.out.println("Any uppercase?: " + test.hasUppercase(str));

		        System.out.println("To Uppercase: " + test.makeUppercase(str));

		        System.out.println("Convert String to Integer and add 10: " + test.convertToIntPlusTen(num));

		    
		
		
    } 
}



