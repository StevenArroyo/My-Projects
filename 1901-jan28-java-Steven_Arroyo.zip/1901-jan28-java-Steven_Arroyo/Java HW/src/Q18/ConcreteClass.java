package Q18;

public class ConcreteClass extends AbstractClass {

	 // Overridden method to determine whether input string contains any uppercase letters

    @Override

    public boolean hasUppercase(String str)

    {

        // Loop through input string

        for ( int i = 0; i < str.length(); i++)

        {

            // If current character's ASCII table value is between 65 and 90 (capital letters from A to Z), return true

            if ((int)str.charAt(i) >= 65 && (int)str.charAt(i) <= 90)

            {

                return true;

            }

        }

        

        // Otherwise return false

        return false;

    }

    // Overridden method to convert characters in input string to uppercase

    @Override

    public String makeUppercase(String str)

    {

        // Instantiate return string

        String str2 = "";

        

        // Loop through input string

        for (int i = 0; i < str.length(); i++)

        {

            // If current character's ASCII table value is between 97 and 122 (lowercase letters from a to z),

            // convert to uppercase equivalent and append to return string

            if ((int)str.charAt(i) >= 97 && (int)str.charAt(i) <= 122)

            {

                str2 = str2 + (char)((int)str.charAt(i) - 32);

            }

            // Otherwise append current character to return string

            else

            {

                str2 = str2 + str.charAt(i);

            }

        }

        

        // Return converted string

        return str2;

    }

    // Overridden method to convert numerical value stored as string to an integer and add 10

    @Override

    public int convertToIntPlusTen(String str)

    {

        return Integer.parseInt(str) + 10;

    }
}
