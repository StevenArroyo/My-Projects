package Q11;

import Q11_2.*;

public class Q11 {

	public static void main (String[] args) {
		
		System.out.println("First Float Number is: " + Q11_2.Float1);
		System.out.println("Second Float Number is: " + Q11_2.Float2);
	}
	
	
}
