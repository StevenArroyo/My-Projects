package Q19;

import java.util.ArrayList;

public class Q19 {

	private static boolean PrimeNumber(int i)

    {

        int prime = 0;

        

        for(int j = 1; j <= i; j++)

            if( i % j == 0)

                prime++;

            

        if( i <= 3 )

            return true;

        else if( prime > 2)

            return false;

        else

            return true;

    }

    public static void main(String[] args) {

        {

            ArrayList<Integer> list = new ArrayList<Integer>();

            

            for(int i = 1; i <= 10; i++)

                list.add(i);

            

            System.out.println("ArrayList: " + list);

            

            int even = 0;

            int odd = 0;

            

        

            // sum even, sum odd, remove primes

            for(int i = 0; i < list.size(); i++ )

            {

                Integer num = list.get(i);

                

                if( num % 2 == 0 )

                    even = even + num;

                if( num % 2 == 1  )

                    odd = odd + num;

                

                
                // this removes the prime numbers from the list
                if( PrimeNumber(num) )

                {       

                    list.remove(i);

                    i--;  

                }

        

            }

        

            System.out.println("Even Number Sums: " + even);

            System.out.println("Odd Number Sums: " + odd);

            System.out.println( "Not Primes: " + list );

            

        }

    }

}

