package Q10;

public class Q10 {

	public static void main (String[] args) {
		
		int smallestValue; // name the smallest value nothing
		int input1 = 5; //default value
		int input2 = 15; // default value
	
		smallestValue = (input2 > input1) ? 5:15; //ternary statement
		
		System.out.println(smallestValue); //print out the smallest value
	}

	
}
