package Q14;

import java.time.LocalDate;

public class Q14 {

	public static void main (String[] args) {
		
		int cases = 3;
		String sent = "I love learning Core Java";
		double SR = 15;
		
		switch(cases) {
		
		case 1: //Square root of 15
			SR = Math.sqrt(SR);
			System.out.println(SR);
			break;
		
		case 2: // print out today's date using LocalDate.now()
			System.out.println("Today's Date: " + LocalDate.now());
			break;
			
		case 3: // print out the string array using split and for loops
			String[] sent1 = sent.split(" ");
			for(int i = 0; i<sent1.length; i++) {
				System.out.println(sent1[i]);
				
			}
			break;
		}
		
		
		
			
	}
}
