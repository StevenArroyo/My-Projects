package Q4;

public class Q4 {

	
	public static void main (String[] args) {
		
		int i,fact=1;  
		int n=5; //this is the number to calculate factorial from the start
		for(i=1;i<=n;i++)
		{    
		    fact=fact*i;    //If i is less than/equal to 5, multiply the number (5) by 4, 3, 2, 1.
		}    
		  System.out.println("Factorial of "+n+" is: "+fact);    
		}  
		
	}
 
	
	

