package Q8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.io.*;

public class Q8 {

	public static void main(String args[]) {      

		System.out.println("Enter a string ");// enter the whatever string you want

		Scanner sc = new Scanner(System.in); // this lets you type in the console.

		String s = sc.nextLine();

		char[] myArray = s.toCharArray();// the reverse of the character array, aka nerak

		int size = myArray.length; //this enlists what size is of the array using length

		char [] original = Arrays.copyOf(myArray,myArray.length); // the original of the character array, aka karen
		
		for (int i = 0; i < size / 2; i++) { 

		  char temp = myArray[i];

		  myArray[i] = myArray[size-i-1];

		  myArray[size-i-1] = temp;

		}

		System.out.println("Original Array"+ Arrays.toString(original)); //print out the karen as karen

		System.out.println("Reverse Array"+ Arrays.toString(myArray)); // print out karen as nerak
		if(Arrays.equals(myArray, original)) {

		  System.out.println("Entered string is a palindrome"); 

		} else {

		  System.out.println("Entered string is not a palindrome");

		}

	}

}
	
	

