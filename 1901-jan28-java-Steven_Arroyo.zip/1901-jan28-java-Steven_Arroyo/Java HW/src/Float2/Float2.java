package Float2;

public class Float2 {

}
