package Q20;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.StringTokenizer;

public class Q20 {

	public static void main(String[] args) {
		{

			String line;

			StringTokenizer token = null;

			try (BufferedReader BR = new BufferedReader(
					new FileReader("C:\\Users\\Stv\\Documents\\workspace-sts-3.9.6.RELEASE\\Java HW\\src\\Q20/Stuff.txt"))) {

				while ((line = BR.readLine()) != null) {

					token = new StringTokenizer(line, ":");

					String[] data = { "Name", "Age", "State" };

					int i = 0;

					System.out.println(data[i] + ": " + token.nextToken() + " " + token.nextToken());

					while (token.hasMoreTokens())

					{

						i++;

						System.out.println(data[i] + ": " + token.nextToken());

					}

					System.out.println();

				}

			}

			catch (FileNotFoundException e)

			{

				e.printStackTrace();

			}

			catch (Exception e)

			{

				e.printStackTrace();

			}

		}

	}

}
