-------------------------------------------------------SQL LAB------------------------------------------------------------------
--                                                 Steven J. Arroyo
-------2.0-------

--2.1 SELECT
-- Select all records from the Employee table.
SELECT * FROM employee;

-- Select all records from the Employee table where last name is King.
SELECT * FROM employee WHERE lastname = 'King';

-- Select all records from the Employee table where first name is Andrew and REPORTSTO is NULL.
SELECT * FROM employee WHERE firstname = 'Andrew' AND reportsto IS NULL;


--2.2 ORDER BY

-- Select all albums in Album table and sort result set in descending order by title
SELECT * FROM album ORDER BY title DESC;

-- Select first name from Customer and sort result set in ascending order by city
SELECT firstname FROM customer ORDER BY city;

---------2.3 INSERT INTO
-- Insert two new records into Genre table
INSERT INTO genre VALUES (26, 'Reaggeton');
INSERT INTO genre VALUES (27, 'EDM');

SELECT * FROM genre ORDER BY genreid;


-- Insert two new records into Employee table
INSERT INTO employee VALUES (9, 'Mason', 'Ryan', 'CEO', null, '20-APR-45', null, '1245 Ave', 'Ontario', 'AB','Canada', 'T4K 6M4', '+1 (403) 567-7654', '+1 (780) 345-1234', 'ryan@chinookcorp.com');                                       
INSERT INTO employee VALUES (10, 'Umpire', 'Tori', 'COO', null, '15-SEP-46', null, '5643 Blvd', 'Ontario', 'AB','Canada', 'T9K 4P3', '+1 (403) 986-5463', '+1 (780) 876-9011', 'tori@chinookcorp.com');


-- Insert two new records into Customer table
INSERT INTO customer VALUES(60, 'Amy', 'Napper', 'Microsoft', null, 'Tampa', 'FL', 'USA', null, null, null, 'amyn@gmail.com', 3);
INSERT INTO customer VALUES(61, 'David', 'Momoa', 'Epic Games', null, 'Cary', 'NC', 'USA', null, null, null, 'davidm@gmail.com', 5);

--2.4 UPDATE 
-- Update Aaron Mitchell in Customer table to Robert Walter
UPDATE customer SET firstname = 'Robert', lastname = 'Walter' WHERE customerid = 32;

SELECT * FROM artist ORDER BY name;

UPDATE artist SET name = 'CCR' WHERE artistid = 76;


-- 2.5 LIKE 
-- Select all invoices with a billing address like �T%�
SELECT * FROM invoice WHERE billingaddress LIKE 'T%';


-- 2.6 BETWEEN
-- Select all invoices that have a total between 15 and 50
SELECT * FROM invoice WHERE total BETWEEN 15 AND 50;

-- Select all employees hired between 1st of June 2003 and 1st of March 2004
SELECT * FROM employee WHERE hiredate BETWEEN '1-JUN-03' AND '1-MAR-04';


-- 2.7 DELETE

-- Delete a record in Customer table where the name is Robert Walter (There may be constraints that rely on this, find out how to resolve them).
DELETE FROM invoiceline WHERE invoiceid=50 OR invoiceid=61 OR invoiceid=116 OR invoiceid=245 OR invoiceid=268 OR invoiceid=290 OR invoiceid=342;

DELETE FROM invoice WHERE customerid=32;

DELETE FROM customer WHERE firstname='Robert' AND lastname='Walter';


----------------------------- 3.0 SQL Functions


--3.1 System Defined Functions
-- Create a function that returns the current time.
CREATE OR REPLACE FUNCTION timestamp_current
    RETURN TIMESTAMP
    IS timee TIMESTAMP;
    
    BEGIN
        SELECT CURRENT_TIMESTAMP
        INTO timee
        FROM DUAL;
        
        RETURN timee;
    END;
/

SELECT cur_time() FROM DUAL;
/


-- Create a function that returns the length of a mediatype from the mediatype table.
CREATE OR REPLACE FUNCTION nameof_mediatype 
    RETURN NUMBER
    IS len NUMBER;
    BEGIN
        SELECT MAX(LENGTH(NAME))
        INTO len
        FROM MEDIATYPE;
        RETURN(len);
    END;
/

SELECT nameof_mediatype() AS LONGEST_MEDIA_NAME FROM dual;
/

SELECT LENGTH(NAME) FROM MEDIATYPE;
/


-- 3.2 System Defined Aggregate Functions
-- Create a function that returns the average total of all invoices.
CREATE OR REPLACE FUNCTION avgtotal_invoices
    RETURN NUMBER
    IS avgInv NUMBER(10,2);
    BEGIN
        SELECT AVG(TOTAL)
        INTO avgInv
        FROM INVOICE;
        RETURN avgInv;
    END;
/


-- Create a function that returns the most expensive track.
CREATE OR REPLACE FUNCTION expensive_track
    RETURN NUMBER
    IS pricest NUMBER;
    BEGIN
        SELECT MAX(UNITPRICE)
        INTO pricest
        FROM TRACK;
        RETURN pricest;
    END;
/
    
SELECT expensive_track() FROM DUAL;
/
    
    
    
    
-- 3.3 User Defined Scalar Functions
-- Create a function that returns the average price of invoice line items in the invoiceline table
CREATE OR REPLACE FUNCTION AVG_INVOICELINE_FUNCTION
    RETURN NUMBER
    IS avgILine NUMBER(10,2);
    BEGIN
        SELECT AVG(UNITPRICE)
        INTO avgILine
        FROM INVOICELINE;
        RETURN avgILine;
    END;
/

SELECT AVG_INVOICELINE_FUNCTION() FROM DUAL;    
/



-- 3.4 User Defined Table Valued Functions
-- Create a function that returns all employees who are born after 1968.
CREATE OR REPLACE FUNCTION get_employees1968 RETURN SYS_REFCURSOR
IS
    employee_c SYS_REFCURSOR;
BEGIN
    OPEN employee_c FOR SELECT * FROM employee WHERE birthdate >= to_date('01-01-1968', 'DD-MM-YYYY');
    RETURN employee_c;
END;
/
select get_employees1968 from dual;


-------------- 4.0 Stored Procedures

-- 4.1 Basic Stored Procedure
-- Create a stored procedure that selects the first and last names of all the employees.
CREATE OR REPLACE FUNCTION get_EmployeeNames RETURN SYS_REFCURSOR
IS
    name_c SYS_REFCURSOR;
BEGIN
    OPEN name_c FOR SELECT firstname, lastname FROM employee;
    RETURN name_c;
END;
/
SELECT get_EmployeeNames FROM dual;


-- 4.2 Stored Procedure Input Parameters
-- Create a stored procedure that updates the personal information of an employee.
CREATE OR REPLACE PROCEDURE update_employee(e_id IN NUMBER, e_lastname IN VARCHAR2, e_firstname IN VARCHAR2, e_title IN VARCHAR2, e_reportsto IN NUMBER, e_birthdate IN DATE, e_hiredate IN DATE, e_address IN VARCHAR2, e_city IN VARCHAR2, e_state IN VARCHAR2, e_country IN VARCHAR2, e_postalcode IN VARCHAR2, e_phone IN VARCHAR2, e_fax IN VARCHAR2, e_email IN VARCHAR2)
IS
BEGIN
    UPDATE employee SET lastname=e_lastname, firstname=e_firstname, title=e_title, reportsto=e_reportsto, birthdate=e_birthdate, hiredate=e_hiredate, address=e_address, city=e_city, state=e_state, country=e_country, postalcode=e_postalcode, phone=e_phone, fax=e_fax, email=e_email WHERE employeeid=e_id;
    COMMIT;
END;
/

BEGIN
    update_employee(9, 'Mason', 'Ryan', 'CEO', NULL, '20-APR-45', NULL, '1500 Ave', 'Vancouver', NULL, 'Canada', 'T4K 7M4', NULL, NULL, 'ryan@chinookcorp.com');
END;
/

SELECT * FROM employee;


-- Create a stored procedure that returns the managers of an employee.

select * from employee;
CREATE OR REPLACE FUNCTION get_manager(e_id IN NUMBER) RETURN SYS_REFCURSOR
IS
    manager_c SYS_REFCURSOR;
BEGIN
    OPEN manager_c FOR SELECT * FROM employee WHERE employeeid=(SELECT reportsto FROM employee WHERE employeeid=e_id);
    RETURN manager_c;
END;
/

SELECT get_manager(2) FROM dual;




-- 4.3 Stored Procedure Output Parameters
-- Create a stored procedure that returns the name and company of a customer.
CREATE OR REPLACE FUNCTION customerName_customerCompany(c_id IN NUMBER) RETURN SYS_REFCURSOR
IS
    customer_c SYS_REFCURSOR;
BEGIN
    OPEN customer_c FOR SELECT firstname, lastname, company FROM customer WHERE customerid=c_id;
    RETURN customer_c;
END;
/
SELECT customerName_customerCompany(5) FROM dual;




------------------ 5.0 Transaction
--- Create a transaction that given a invoiceId will delete that invoice (There may be constraints that rely on this, find out
--- how to resolve them).
CREATE OR REPLACE PROCEDURE invoice_Deletion(in_id IN NUMBER)
IS
BEGIN
    DELETE FROM invoiceline WHERE invoiceid=in_id;
    DELETE FROM invoice WHERE invoiceid=in_id;
    COMMIT;
END;
/

BEGIN
    invoice_Deletion(10);
END;
/

--- Create a transaction nested within a stored procedure that inserts a new record in the Customer table

CREATE OR REPLACE PROCEDURE customer_Insertion(c_id IN NUMBER, c_fname IN VARCHAR2, c_lname IN VARCHAR2, c_company IN VARCHAR2, c_addr IN VARCHAR2, c_city IN VARCHAR2, c_state IN VARCHAR2, c_country IN VARCHAR2, c_postal IN VARCHAR2, c_phone IN VARCHAR2, c_fax IN VARCHAR2, c_email IN VARCHAR2, c_supportid IN NUMBER)
IS
BEGIN
    INSERT INTO customer VALUES(c_id, c_fname, c_lname, c_company, c_addr, c_city, c_state, c_country, c_postal, c_phone, c_fax, c_email, c_supportid);
    COMMIT;
END;
/

BEGIN
    customer_Insertion(62, 'Ryan', 'Bordy', 'Lame High School', null, null, 'Atlanta', 'Georgia', 'USA', null, null, 'imaginebreaker@gmail.com', 1);
END;
/


------------------- 6.0 TRIGGERS
-- 6.1 AFTER/FOR
---- Create an after insert trigger on the employee table fired after a new record is inserted into the table.
CREATE OR REPLACE TRIGGER insert_Employee
AFTER INSERT ON employee
FOR EACH ROW
BEGIN
    DBMS_OUTPUT.PUT_LINE('Inserted Trigger');
END;
/

---- Create an after update trigger on the album table that fires after a row is inserted in the table
CREATE OR REPLACE TRIGGER insert_Album
AFTER INSERT ON album
FOR EACH ROW
BEGIN
    DBMS_OUTPUT.PUT_LINE('after Trigger');
END;
/

---- Create an after delete trigger on the customer table that fires after a row is deleted from the table.
CREATE OR REPLACE TRIGGER delete_Customer
AFTER DELETE ON customer
FOR EACH ROW
BEGIN
    DBMS_OUTPUT.PUT_LINE('Delete Trigger');
END;
/



---------------- 7.0 JOINS

-- 7.1 INNER

SELECT i.INVOICEID AS INVOICEID, c.FIRSTNAME AS FIRSTNAME, c.LASTNAME AS LASTNAME
FROM CUSTOMER c
INNER JOIN INVOICE i ON i.CUSTOMERID = c.CUSTOMERID;
/


-- 7.2 OUTER

SELECT c.customerid, firstname, lastname, invoiceid, total 
FROM customer c FULL OUTER JOIN invoice i ON c.customerid=i.customerid;
/



-- 7.3 RIGHT

SELECT name, title FROM artist ar RIGHT OUTER JOIN album al ON ar.artistid=al.artistid;



-- 7.4 CROSS

SELECT * FROM album CROSS JOIN artist ORDER BY name ASC;


-- 7.5 SELF

SELECT * FROM employee e JOIN employee m ON e.employeeid=m.reportsto ORDER BY e.lastname ASC;



COMMIT;









